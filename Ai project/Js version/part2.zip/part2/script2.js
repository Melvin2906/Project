import { sendMessage } from './script.js'

const sent = document.getElementById("send-button")
const userMessage = document.getElementById("userInput").value
sent.addEventListener("click", () => sendMessage(userMessage))

class Autogrow extends HTMLTextAreaElement {
    
    constructor () {
        super ()
        this.onFocus = this.onFocus.bind(this)
        this.Autogrow = this.Autogrow.bind(this)
    }

    connectedCallback () {
       this.addEventListener("focus", this.onFocus)
       this.addEventListener("input", this.Autogrow)
    }

    disconnectedCallback () {

    }

    onFocus () {
        this.Autogrow
        this.removeEventListener("focus", this.onFocus)
    }

    Autogrow () {
        this.style.overflow = "hidden"
        if (this.scrollHeight < 10) {
            this.style.height = this.scrollHeight + "px"
        } else if (this.scrollHeight > 10) {
            this.style.overflow = "auto"
        }
        this.removeEventListener("input", this.onFocus)
    }
}

customElements.define("textarea-autogrow", Autogrow, {extends: 'textarea'})

